package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.nio.charset.StandardCharsets;

@SpringBootApplication
@RestController
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}
@GetMapping("/hash")
public String getCheckSum () {
	String data = "Hello World Check Sum!";
	String name = "Emma Johnson";
	
	try {
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		byte[] hashBytes = digest.digest(data.getBytes(StandardCharsets.UTF_8));
		StringBuilder hexString = new StringBuilder();
		
		for (byte b : hashBytes) {
			hexString.append(String.format("%02x", b));
		}
		
		return "Name: " + name + "\nInput: " + data + "\nSHA-256 Hash: " + hexString.toString();
	} catch (NoSuchAlgorithmException e) {
		return "Error computing checksum: " + e.getMessage();
	}
	}
}

